import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name"),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  imageName: text("image_name"),
  upvotes: integer("upvotes").default(0).notNull(),
  downvotes: integer("downvotes").default(0).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  isSticky: boolean("is_sticky").default(false).notNull(),
  tags: json("tags").$type<string[]>().default([]),
  ipHash: text("ip_hash"), // Hashed IP for tracking without storing actual IP
  userAgent: text("user_agent"), // Browser fingerprint for hacker aesthetic
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const votes = pgTable("votes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").references(() => posts.id).notNull(),
  ipHash: text("ip_hash").notNull(), // To prevent duplicate voting
  voteType: text("vote_type").notNull(), // 'up' or 'down'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").references(() => posts.id).notNull(),
  name: text("name"),
  content: text("content").notNull(),
  ipHash: text("ip_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ipHash: text("ip_hash").notNull(),
  userAgent: text("user_agent"),
  lastSeen: timestamp("last_seen").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

// Relations
export const postsRelations = relations(posts, ({ many }) => ({
  votes: many(votes),
  comments: many(comments),
}));

export const votesRelations = relations(votes, ({ one }) => ({
  post: one(posts, { fields: [votes.postId], references: [posts.id] }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  post: one(posts, { fields: [comments.postId], references: [posts.id] }),
}));

// Schemas
export const insertPostSchema = createInsertSchema(posts).pick({
  name: true,
  content: true,
  imageUrl: true,
  imageName: true,
  tags: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  name: true,
  content: true,
  postId: true,
});

export const insertVoteSchema = createInsertSchema(votes).pick({
  postId: true,
  voteType: true,
});

// Types
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type Vote = typeof votes.$inferSelect;
export type Session = typeof sessions.$inferSelect;
