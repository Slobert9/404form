export default function Footer() {
  return (
    <footer className="border-t border-dark-border bg-dark-surface/50 mt-16">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-xs text-gray-500 font-mono mb-4 md:mb-0">
            © 2024 404 FORUM • SECURE_NETWORK • ALL_TRANSMISSIONS_LOGGED
          </div>
          <div className="flex items-center space-x-6 text-xs text-gray-500 font-mono">
            <span><i className="fas fa-shield-alt mr-1 text-terminal-green"></i>ENCRYPTED</span>
            <span><i className="fas fa-eye-slash mr-1 text-terminal-blue"></i>ANONYMOUS</span>
            <span><i className="fas fa-lock mr-1 text-terminal-amber"></i>SECURE</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
