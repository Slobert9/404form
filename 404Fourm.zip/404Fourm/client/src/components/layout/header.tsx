import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="border-b border-dark-border bg-dark-surface/50 backdrop-blur-sm sticky top-0 z-20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-terminal-green rounded-sm flex items-center justify-center">
              <i className="fas fa-terminal text-dark-bg text-sm"></i>
            </div>
            <Link href="/">
              <h1 className="text-2xl font-mono font-bold text-terminal-green glitch-text cursor-pointer">
                404 FORUM
              </h1>
            </Link>
            <span className="text-xs text-gray-500 font-mono">[SECURE_NETWORK]</span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/">
              <button className={`text-sm font-mono transition-colors ${
                location === "/" ? "text-terminal-green" : "text-gray-300 hover:text-terminal-green"
              }`}>
                <i className="fas fa-comments mr-2"></i>FORUM
              </button>
            </Link>
            <Link href="/gallery">
              <button className={`text-sm font-mono transition-colors ${
                location === "/gallery" ? "text-terminal-green" : "text-gray-300 hover:text-terminal-green"
              }`}>
                <i className="fas fa-images mr-2"></i>GALLERY
              </button>
            </Link>
            <div className="text-xs text-terminal-green font-mono">
              <i className="fas fa-circle text-xs mr-1"></i>ONLINE
            </div>
          </nav>
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden text-terminal-green"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t border-dark-border">
            <div className="flex flex-col space-y-3">
              <Link href="/" onClick={() => setMobileMenuOpen(false)}>
                <button className={`text-sm font-mono transition-colors text-left ${
                  location === "/" ? "text-terminal-green" : "text-gray-300 hover:text-terminal-green"
                }`}>
                  <i className="fas fa-comments mr-2"></i>FORUM
                </button>
              </Link>
              <Link href="/gallery" onClick={() => setMobileMenuOpen(false)}>
                <button className={`text-sm font-mono transition-colors text-left ${
                  location === "/gallery" ? "text-terminal-green" : "text-gray-300 hover:text-terminal-green"
                }`}>
                  <i className="fas fa-images mr-2"></i>GALLERY
                </button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
