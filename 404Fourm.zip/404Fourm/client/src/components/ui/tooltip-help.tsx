import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { HelpCircle } from "lucide-react";

interface TooltipHelpProps {
  content: string;
}

export default function TooltipHelp({ content }: TooltipHelpProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <HelpCircle className="w-4 h-4 text-gray-500 hover:text-terminal-green transition-colors cursor-help" />
      </TooltipTrigger>
      <TooltipContent className="bg-dark-elevated border-dark-border text-gray-300 font-mono text-xs max-w-xs">
        <p>{content}</p>
      </TooltipContent>
    </Tooltip>
  );
}