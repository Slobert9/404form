import { useQuery } from "@tanstack/react-query";
import type { Post } from "@shared/schema";
import { Users, MessageCircle, Image, Activity } from "lucide-react";

export default function StatsBar() {
  const { data: posts = [] } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
  });

  const { data: images = [] } = useQuery<Post[]>({
    queryKey: ["/api/images"],
  });

  const uniqueUsers = new Set(posts.map(p => p.name || 'Anonymous')).size;
  const totalPosts = posts.length;
  const totalImages = images.length;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="post-card p-4 rounded-lg text-center">
        <Activity className="w-5 h-5 text-terminal-green mx-auto mb-2" />
        <div className="text-lg font-mono text-terminal-green">{totalPosts}</div>
        <div className="text-xs text-gray-500 font-mono">TRANSMISSIONS</div>
      </div>
      
      <div className="post-card p-4 rounded-lg text-center">
        <Image className="w-5 h-5 text-terminal-blue mx-auto mb-2" />
        <div className="text-lg font-mono text-terminal-blue">{totalImages}</div>
        <div className="text-xs text-gray-500 font-mono">IMAGES</div>
      </div>
      
      <div className="post-card p-4 rounded-lg text-center">
        <Users className="w-5 h-5 text-terminal-amber mx-auto mb-2" />
        <div className="text-lg font-mono text-terminal-amber">{uniqueUsers}</div>
        <div className="text-xs text-gray-500 font-mono">AGENTS</div>
      </div>
      
      <div className="post-card p-4 rounded-lg text-center">
        <div className="w-5 h-5 bg-terminal-green rounded-full mx-auto mb-2 animate-pulse"></div>
        <div className="text-lg font-mono text-terminal-green">LIVE</div>
        <div className="text-xs text-gray-500 font-mono">STATUS</div>
      </div>
    </div>
  );
}