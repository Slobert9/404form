import { useEffect } from "react";
import { X } from "lucide-react";
import type { Post } from "@shared/schema";

interface ImageModalProps {
  image: Post;
  onClose: () => void;
}

export default function ImageModal({ image, onClose }: ImageModalProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'auto';
    };
  }, [onClose]);

  const formatTimestamp = (date: Date | string) => {
    const d = new Date(date);
    return d.toISOString().replace('T', '_').substring(0, 19);
  };

  return (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div className="max-w-4xl max-h-full relative" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={onClose}
          className="absolute -top-12 right-0 text-white hover:text-terminal-green transition-colors"
        >
          <X size={24} />
        </button>
        <img
          src={image.imageUrl!}
          alt={image.imageName || "Gallery image"}
          className="max-w-full max-h-full object-contain rounded-lg border border-dark-border"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 rounded-b-lg">
          <div className="text-white font-mono text-sm">
            <div className="flex items-center justify-between">
              <span>
                Posted by: <span className="text-terminal-green">{image.name || 'Anonymous'}</span>
              </span>
              <span>{formatTimestamp(image.createdAt)}</span>
            </div>
            {image.content && (
              <p className="mt-2 text-gray-300 text-sm">{image.content}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
