import type { Post } from "@shared/schema";

interface ImageGalleryProps {
  images: Post[];
  onImageClick: (image: Post) => void;
}

export default function ImageGallery({ images, onImageClick }: ImageGalleryProps) {
  const formatTimestamp = (date: Date | string) => {
    const d = new Date(date);
    return d.toISOString().replace('T', '_').substring(0, 16);
  };

  const getRandomColor = (index: number) => {
    const colors = ['terminal-green', 'terminal-blue', 'terminal-amber'];
    return colors[index % colors.length];
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {images.map((image, index) => {
        const colorClass = getRandomColor(index);
        return (
          <div
            key={image.id}
            className="post-card rounded-lg overflow-hidden group cursor-pointer"
            onClick={() => onImageClick(image)}
          >
            <div className="relative">
              <img
                src={image.imageUrl!}
                alt={image.imageName || "Gallery image"}
                className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="absolute bottom-2 left-2 text-xs font-mono text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <span>{formatTimestamp(image.createdAt)}</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <span className={`text-${colorClass} font-mono text-sm`}>
                  {image.name || 'Anonymous'}
                </span>
                <span className="text-xs text-gray-500 font-mono">
                  #IMG_{String(index + 1).padStart(3, '0')}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
