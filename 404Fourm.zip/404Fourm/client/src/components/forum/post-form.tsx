import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send, Upload, Loader2, Image, User, MessageSquare } from "lucide-react";
import TooltipHelp from "@/components/ui/tooltip-help";

export default function PostForm() {
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createPostMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/posts", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create post");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      
      // Reset form
      setName("");
      setContent("");
      setTags("");
      setImage(null);
      
      // Reset file input
      const fileInput = document.getElementById("imageUpload") as HTMLInputElement;
      if (fileInput) fileInput.value = "";
      
      toast({
        title: "TRANSMISSION SENT",
        description: "Your message has been posted to the network.",
      });
    },
    onError: (error) => {
      toast({
        title: "TRANSMISSION FAILED",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast({
        title: "ERROR",
        description: "Message content is required.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    if (name.trim()) formData.append("name", name.trim());
    formData.append("content", content.trim());
    if (tags.trim()) formData.append("tags", tags.trim());
    if (image) formData.append("image", image);

    createPostMutation.mutate(formData);
  };

  return (
    <div className="mb-8 p-6 post-card rounded-lg">
      <h3 className="text-lg font-mono text-terminal-blue mb-4">
        <i className="fas fa-plus-circle mr-2"></i>NEW_TRANSMISSION
      </h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Label className="text-sm font-mono text-gray-400 flex items-center">
              <User className="w-4 h-4 mr-1" />ALIAS [OPTIONAL]
            </Label>
            <TooltipHelp content="Choose a username or leave blank to remain anonymous. Your family will know it's you anyway!" />
          </div>
          <Input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Anonymous_User"
            className="terminal-input font-mono text-sm"
            maxLength={50}
          />
          <div className="text-xs text-gray-500 font-mono mt-1">
            {name.length}/50 characters
          </div>
        </div>
        
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Label className="text-sm font-mono text-gray-400 flex items-center">
              <MessageSquare className="w-4 h-4 mr-1" />MESSAGE_CONTENT
            </Label>
            <TooltipHelp content="Share your thoughts, ask questions, or post family updates. Keep it interesting!" />
          </div>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Enter your transmission... What's on your mind?"
            rows={4}
            className="terminal-input font-mono text-sm resize-vertical"
            required
            maxLength={2000}
          />
          <div className="text-xs text-gray-500 font-mono mt-1">
            {content.length}/2000 characters
          </div>
        </div>
        
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Label className="text-sm font-mono text-gray-400 flex items-center">
              <Image className="w-4 h-4 mr-1" />ATTACH_IMAGE [OPTIONAL]
            </Label>
            <TooltipHelp content="Upload photos, memes, or screenshots. Max file size: 10MB. Supported formats: JPG, PNG, GIF, WebP" />
          </div>
          <Input
            type="file"
            id="imageUpload"
            accept="image/*"
            onChange={(e) => setImage(e.target.files?.[0] || null)}
            className="terminal-input font-mono text-sm file:bg-terminal-green file:text-dark-bg file:border-0 file:px-4 file:py-2 file:rounded file:font-mono file:text-sm file:mr-4"
          />
          {image && (
            <div className="mt-2 text-xs text-terminal-green font-mono">
              Selected: {image.name} ({(image.size / 1024 / 1024).toFixed(2)} MB)
            </div>
          )}
        </div>
        
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Label className="text-sm font-mono text-gray-400 flex items-center">
              <i className="fas fa-tags w-4 h-4 mr-1"></i>TAGS [OPTIONAL]
            </Label>
            <TooltipHelp content="Add tags separated by commas (e.g. family, memes, tech). Helps organize and search posts." />
          </div>
          <Input
            type="text"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="family, memes, tech..."
            className="terminal-input font-mono text-sm"
            maxLength={100}
          />
          <div className="text-xs text-gray-500 font-mono mt-1">
            {tags.length}/100 characters
          </div>
        </div>
        
        <Button
          type="submit"
          disabled={createPostMutation.isPending}
          className="btn-terminal px-6 py-3 font-mono text-sm rounded hover:text-dark-bg transition-all duration-300"
        >
          {createPostMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              TRANSMITTING...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              TRANSMIT_MESSAGE
            </>
          )}
        </Button>
      </form>
    </div>
  );
}
