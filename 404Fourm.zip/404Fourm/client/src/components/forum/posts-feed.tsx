import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Post } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { User, ArrowUp, ArrowDown, MessageCircle, Clock, Image as ImageIcon, Search, Filter, Eye, Tag } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import CommentSection from "./comment-section";

export default function PostsFeed() {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: allPosts = [], isLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
  });

  const voteMutation = useMutation({
    mutationFn: async ({ postId, voteType }: { postId: string; voteType: 'up' | 'down' }) => {
      return await apiRequest(`/api/posts/${postId}/vote`, {
        method: 'POST',
        body: JSON.stringify({ voteType }),
        headers: { 'Content-Type': 'application/json' },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const incrementViewMutation = useMutation({
    mutationFn: async (postId: string) => {
      return await apiRequest(`/api/posts/${postId}/view`, {
        method: 'POST',
      });
    },
  });

  // Filter posts based on search term
  const posts = allPosts.filter(post => 
    post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (post.name && post.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-mono text-terminal-blue">
            <i className="fas fa-stream mr-2"></i>LIVE_FEED
          </h3>
        </div>
        {[...Array(3)].map((_, i) => (
          <div key={i} className="post-card rounded-lg p-6 animate-pulse">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-dark-elevated rounded-full"></div>
                <div>
                  <div className="h-4 bg-dark-elevated rounded w-24 mb-1"></div>
                  <div className="h-3 bg-dark-elevated rounded w-32"></div>
                </div>
              </div>
            </div>
            <div className="mb-4">
              <div className="h-4 bg-dark-elevated rounded mb-2"></div>
              <div className="h-4 bg-dark-elevated rounded mb-2 w-4/5"></div>
              <div className="h-4 bg-dark-elevated rounded w-3/5"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (allPosts.length === 0 && !isLoading) {
    return (
      <div className="text-center py-16">
        <div className="mb-6">
          <i className="fas fa-comments text-6xl text-gray-600 mb-4"></i>
          <h3 className="text-xl font-mono text-gray-400 mb-2">NO TRANSMISSIONS YET</h3>
          <p className="text-gray-500 text-sm mb-4">Be the first to post to the network.</p>
          <div className="text-xs font-mono text-gray-600">
            Waiting for incoming signals... 📡
          </div>
        </div>
      </div>
    );
  }

  if (posts.length === 0 && searchTerm) {
    return (
      <div>
        {/* Search Bar */}
        <div className="mb-6 flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
            <Input
              type="text"
              placeholder="Search transmissions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="terminal-input font-mono text-sm pl-10"
            />
          </div>
          <span className="text-xs text-gray-500 font-mono">
            [{allPosts.length} TOTAL]
          </span>
        </div>
        
        <div className="text-center py-16">
          <Search className="text-6xl text-gray-600 mb-4 mx-auto" />
          <h3 className="text-xl font-mono text-gray-400 mb-2">NO MATCHES FOUND</h3>
          <p className="text-gray-500 text-sm">No transmissions match "{searchTerm}"</p>
        </div>
      </div>
    );
  }

  const formatTimestamp = (date: Date | string) => {
    const d = new Date(date);
    return d.toISOString().replace('T', '_').substring(0, 19);
  };

  const formatRelativeTime = (date: Date | string) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  const handleVote = (postId: string, voteType: 'up' | 'down') => {
    voteMutation.mutate({ postId, voteType });
  };

  const handleImageClick = (postId: string) => {
    incrementViewMutation.mutate(postId);
  };

  const toggleComments = (postId: string) => {
    const newExpanded = new Set(expandedComments);
    if (newExpanded.has(postId)) {
      newExpanded.delete(postId);
    } else {
      newExpanded.add(postId);
    }
    setExpandedComments(newExpanded);
  };

  const getRandomColor = (index: number) => {
    const colors = ['terminal-green', 'terminal-blue', 'terminal-amber'];
    return colors[index % colors.length];
  };

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="mb-6 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            type="text"
            placeholder="Search transmissions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="terminal-input font-mono text-sm pl-10"
          />
        </div>
        <span className="text-xs text-gray-500 font-mono">
          [{allPosts.length} TOTAL]
        </span>
      </div>

      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-mono text-terminal-blue">
          <i className="fas fa-stream mr-2"></i>LIVE_FEED
        </h3>
        <span className="text-xs text-gray-500 font-mono">
          [<span>{posts.length}</span> {searchTerm ? 'FILTERED' : 'TRANSMISSIONS'}]
        </span>
      </div>
      
      {posts.map((post, index) => {
        const colorClass = getRandomColor(index);
        return (
          <div key={post.id} className="post-card rounded-lg p-6 fade-in">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 bg-${colorClass}/20 rounded-full flex items-center justify-center`}>
                  <User className={`text-${colorClass} w-4 h-4`} />
                </div>
                <div>
                  <span className={`text-${colorClass} font-mono text-sm`}>
                    {post.name || 'Anonymous'}
                  </span>
                  <div className="flex items-center gap-2 text-xs text-gray-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatRelativeTime(post.createdAt)}
                    </span>
                    <span>•</span>
                    <span>{formatTimestamp(post.createdAt)}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {post.imageUrl && (
                  <ImageIcon className="w-4 h-4 text-terminal-blue" />
                )}
                <span className="text-xs text-gray-600 font-mono">
                  [#{String(index + 1).padStart(3, '0')}]
                </span>
              </div>
            </div>
            
            <div className="mb-4">
              <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
                {post.content}
              </p>
            </div>

            {/* Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className="mb-4">
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="text-xs bg-terminal-green/20 text-terminal-green px-2 py-1 rounded font-mono border border-terminal-green/30"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {post.imageUrl && (
              <div className="mb-4 rounded-lg overflow-hidden border border-dark-border">
                <img
                  src={post.imageUrl}
                  alt={post.imageName || "Uploaded image"}
                  className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300 cursor-pointer"
                  onClick={() => handleImageClick(post.id)}
                />
              </div>
            )}
            
            <div className="flex items-center justify-between text-xs text-gray-500 font-mono">
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => handleVote(post.id, 'up')}
                  className="hover:text-terminal-green transition-colors flex items-center gap-1"
                  disabled={voteMutation.isPending}
                >
                  <ArrowUp className="w-3 h-3" />
                  <span>{post.upvotes || 0}</span>
                </button>
                <button 
                  onClick={() => handleVote(post.id, 'down')}
                  className="hover:text-terminal-red transition-colors flex items-center gap-1"
                  disabled={voteMutation.isPending}
                >
                  <ArrowDown className="w-3 h-3" />
                  <span>{post.downvotes || 0}</span>
                </button>
                <button 
                  onClick={() => toggleComments(post.id)}
                  className="hover:text-terminal-blue transition-colors flex items-center gap-1"
                >
                  <MessageCircle className="w-3 h-3" />
                  <span>RESPOND</span>
                </button>
                <div className="flex items-center gap-1 text-gray-600">
                  <Eye className="w-3 h-3" />
                  <span>{post.viewCount || 0}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {post.userAgent && (
                  <span className="text-gray-600" title={post.userAgent}>
                    🖥️
                  </span>
                )}
                <span>NODE: {post.ipHash?.substring(0, 8) || 'UNKNOWN'}</span>
              </div>
            </div>
            
            {/* Comment Section */}
            <CommentSection 
              postId={post.id} 
              isExpanded={expandedComments.has(post.id)} 
            />
          </div>
        );
      })}
    </div>
  );
}
