import { useQuery } from "@tanstack/react-query";
import { Users, MessageSquare, Image, Eye, TrendingUp } from "lucide-react";

export default function LiveStats() {
  const { data: posts = [] } = useQuery<any[]>({
    queryKey: ["/api/posts"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: activeUsers = { activeUsers: 0 } } = useQuery<{ activeUsers: number }>({
    queryKey: ["/api/sessions/active"],
    refetchInterval: 15000, // Refresh every 15 seconds
  });

  const totalPosts = posts.length;
  const totalImages = posts.filter(p => p.imageUrl).length;
  const totalViews = posts.reduce((sum, p) => sum + (p.viewCount || 0), 0);
  const totalUpvotes = posts.reduce((sum, p) => sum + (p.upvotes || 0), 0);

  return (
    <div className="bg-dark-card border border-dark-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-mono text-terminal-green text-sm">
          [SYSTEM_STATUS]
        </h3>
        <div className="flex items-center text-xs text-gray-500 font-mono">
          <span className="w-2 h-2 bg-terminal-green rounded-full mr-2 animate-pulse"></span>
          LIVE
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Users className="w-4 h-4 text-terminal-blue mr-1" />
          </div>
          <div className="text-lg font-mono text-terminal-blue">
            {activeUsers.activeUsers}
          </div>
          <div className="text-xs text-gray-500 font-mono">ACTIVE</div>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <MessageSquare className="w-4 h-4 text-terminal-amber mr-1" />
          </div>
          <div className="text-lg font-mono text-terminal-amber">
            {totalPosts}
          </div>
          <div className="text-xs text-gray-500 font-mono">POSTS</div>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Image className="w-4 h-4 text-terminal-green mr-1" />
          </div>
          <div className="text-lg font-mono text-terminal-green">
            {totalImages}
          </div>
          <div className="text-xs text-gray-500 font-mono">IMAGES</div>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Eye className="w-4 h-4 text-purple-400 mr-1" />
          </div>
          <div className="text-lg font-mono text-purple-400">
            {totalViews}
          </div>
          <div className="text-xs text-gray-500 font-mono">VIEWS</div>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <TrendingUp className="w-4 h-4 text-terminal-red mr-1" />
          </div>
          <div className="text-lg font-mono text-terminal-red">
            {totalUpvotes}
          </div>
          <div className="text-xs text-gray-500 font-mono">UPLINKS</div>
        </div>
      </div>
    </div>
  );
}