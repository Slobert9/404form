import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { formatDistanceToNow } from "date-fns";
import { Send, User, MessageCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Comment {
  id: string;
  postId: string;
  name: string | null;
  content: string;
  createdAt: string;
  ipHash: string | null;
}

interface CommentSectionProps {
  postId: string;
  isExpanded: boolean;
}

export default function CommentSection({ postId, isExpanded }: CommentSectionProps) {
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [], isLoading } = useQuery<Comment[]>({
    queryKey: [`/api/posts/${postId}/comments`],
    enabled: isExpanded,
  });

  const createCommentMutation = useMutation({
    mutationFn: async (data: { name: string; content: string }) => {
      const response = await fetch(`/api/posts/${postId}/comments`, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to create comment');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setName("");
      setContent("");
      toast({
        description: "Comment transmitted to the network",
      });
    },
    onError: () => {
      toast({
        description: "Failed to transmit comment",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      toast({
        description: "Comment content required",
        variant: "destructive",
      });
      return;
    }

    createCommentMutation.mutate({
      name: name.trim() || "ANONYMOUS",
      content: content.trim(),
    });
  };

  if (!isExpanded) return null;

  return (
    <div className="mt-4 border-t border-dark-border pt-4">
      <div className="mb-4">
        <h4 className="text-sm font-mono text-terminal-green mb-3 flex items-center">
          <MessageCircle className="w-4 h-4 mr-2" />
          RESPONSE_THREAD [{comments.length}]
        </h4>

        {/* Comment Form */}
        <form onSubmit={handleSubmit} className="mb-4 p-3 bg-dark-bg border border-dark-border rounded">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
            <div>
              <Label className="text-xs font-mono text-gray-400 mb-1 block">
                <User className="w-3 h-3 inline mr-1" />
                HANDLE [OPTIONAL]
              </Label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ANONYMOUS"
                className="terminal-input font-mono text-xs"
                maxLength={50}
              />
            </div>
            <div className="flex items-end">
              <Button 
                type="submit" 
                disabled={createCommentMutation.isPending || !content.trim()}
                className="terminal-button text-xs font-mono flex items-center gap-2"
              >
                {createCommentMutation.isPending ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Send className="w-3 h-3" />
                )}
                TRANSMIT
              </Button>
            </div>
          </div>
          
          <div>
            <Label className="text-xs font-mono text-gray-400 mb-1 block">
              MESSAGE CONTENT
            </Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Enter your response to the network..."
              className="terminal-input font-mono text-xs resize-none"
              rows={3}
              maxLength={500}
            />
            <div className="text-xs text-gray-500 font-mono mt-1">
              {content.length}/500 characters
            </div>
          </div>
        </form>

        {/* Comments List */}
        {isLoading ? (
          <div className="text-center py-4">
            <Loader2 className="w-4 h-4 animate-spin mx-auto mb-2" />
            <div className="text-xs font-mono text-gray-500">Loading responses...</div>
          </div>
        ) : comments.length > 0 ? (
          <div className="space-y-3">
            {comments.map((comment) => (
              <div key={comment.id} className="p-3 bg-dark-card border border-dark-border rounded text-sm">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <User className="w-3 h-3 mr-2 text-gray-500" />
                    <span className="font-mono text-terminal-blue">
                      {comment.name || "ANONYMOUS"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 font-mono">
                    <span>{formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                    <span>NODE: {comment.ipHash?.substring(0, 8) || 'UNKNOWN'}</span>
                  </div>
                </div>
                <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
                  {comment.content}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-xs font-mono text-gray-500">
            No responses detected. Be the first to break the silence.
          </div>
        )}
      </div>
    </div>
  );
}