import ImageGallery from "@/components/gallery/image-gallery";
import ImageModal from "@/components/gallery/image-modal";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Post } from "@shared/schema";

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<Post | null>(null);
  
  const { data: images = [], isLoading } = useQuery<Post[]>({
    queryKey: ["/api/images"],
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-mono text-terminal-blue mb-4">
          <i className="fas fa-images mr-3"></i>IMAGE_GALLERY
        </h2>
        <p className="text-gray-400 text-sm">
          Visual transmissions from the network. All uploaded images are displayed here.
        </p>
        <div className="mt-4 flex items-center space-x-4 text-xs text-gray-500 font-mono">
          <span><i className="fas fa-image mr-1"></i>{images.length} IMAGES</span>
          <span><i className="fas fa-clock mr-1"></i>LIVE_FEED</span>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="post-card rounded-lg overflow-hidden animate-pulse">
              <div className="w-full h-48 bg-dark-elevated"></div>
              <div className="p-4">
                <div className="h-4 bg-dark-elevated rounded mb-2"></div>
                <div className="h-3 bg-dark-elevated rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      ) : images.length === 0 ? (
        <div className="text-center py-16">
          <i className="fas fa-image text-6xl text-gray-600 mb-4"></i>
          <h3 className="text-xl font-mono text-gray-400 mb-2">NO IMAGES FOUND</h3>
          <p className="text-gray-500 text-sm">Upload some images to the forum to see them here.</p>
        </div>
      ) : (
        <ImageGallery images={images} onImageClick={setSelectedImage} />
      )}
      
      {selectedImage && (
        <ImageModal 
          image={selectedImage} 
          onClose={() => setSelectedImage(null)} 
        />
      )}
    </div>
  );
}
