import PostForm from "@/components/forum/post-form";
import PostsFeed from "@/components/forum/posts-feed";
import LiveStats from "@/components/forum/live-stats";
import StatsBar from "@/components/ui/stats-bar";

export default function Forum() {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Welcome Banner */}
      <div className="mb-8 p-6 post-card rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-mono text-terminal-green">
            404 FORUM
          </h2>
          <span className="text-xs text-gray-500 font-mono">[watching_you_watching_us]</span>
        </div>
        <div className="mb-4">
          <h3 className="text-lg font-mono text-terminal-blue mb-2">
            WELCOME TO THE NETWORK
          </h3>
          <span className="text-xs text-gray-500 font-mono">[encrypted_and_redacted]</span>
        </div>
        <p className="text-gray-400 text-sm leading-relaxed mb-4">
          A covert digital meeting spot for the terminally curious. No registration required because we already know who you are. Post your thoughts, images, and cryptic riddles. All transmissions are logged and encrypted for your protection.
        </p>
        <div className="flex items-center space-x-4 text-xs text-gray-500 font-mono">
          <span><i className="fas fa-users mr-1"></i>ONLINE</span>
          <span><i className="fas fa-eye mr-1"></i>ANONYMOUS</span>
          <span><i className="fas fa-eye-slash mr-1"></i>UNDER_SURVEILLANCE</span>
        </div>
      </div>

      <LiveStats />
      <PostForm />
      <PostsFeed />
    </div>
  );
}
