import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertPostSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));

  // Middleware to track user sessions and get IP
  app.use(async (req, res, next) => {
    const ipAddress = req.ip || req.connection.remoteAddress || 'unknown';
    const userAgent = req.get('User-Agent');
    
    try {
      await storage.trackSession(ipAddress, userAgent);
    } catch (error) {
      console.error('Session tracking error:', error);
    }
    
    // Store IP for later use in routes
    (req as any).clientIp = ipAddress;
    next();
  });

  // Get all posts
  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getAllPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });

  // Create new post
  app.post("/api/posts", upload.single('image'), async (req, res) => {
    try {
      const { name, content, tags } = req.body;
      const ipAddress = (req as any).clientIp;
      const userAgent = req.get('User-Agent');
      
      // Validate required content
      if (!content || content.trim().length === 0) {
        return res.status(400).json({ error: "Content is required" });
      }

      const postData: any = {
        name: name || null,
        content: content.trim(),
        tags: tags ? tags.split(',').map((tag: string) => tag.trim()).filter(Boolean) : [],
      };

      // Handle uploaded image
      if (req.file) {
        const fileExtension = path.extname(req.file.originalname);
        const newFileName = `${req.file.filename}${fileExtension}`;
        const newPath = path.join(uploadDir, newFileName);
        
        // Rename file to include extension
        fs.renameSync(req.file.path, newPath);
        
        postData.imageUrl = `/uploads/${newFileName}`;
        postData.imageName = req.file.originalname;
      }

      // Validate with schema
      const validatedData = insertPostSchema.parse(postData);
      
      const post = await storage.createPost(validatedData, ipAddress, userAgent);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      if (error instanceof multer.MulterError) {
        return res.status(400).json({ error: error.message });
      }
      console.error("Error creating post:", error);
      res.status(500).json({ error: "Failed to create post" });
    }
  });

  // Vote on post
  app.post("/api/posts/:id/vote", async (req, res) => {
    try {
      const { id } = req.params;
      const { voteType } = req.body;
      const ipAddress = (req as any).clientIp;

      if (voteType !== 'up' && voteType !== 'down') {
        return res.status(400).json({ error: "Invalid vote type" });
      }

      const result = await storage.voteOnPost(id, voteType, ipAddress);
      res.json(result);
    } catch (error) {
      console.error("Error voting on post:", error);
      res.status(500).json({ error: "Failed to vote on post" });
    }
  });

  // Get user's vote for a post
  app.get("/api/posts/:id/vote", async (req, res) => {
    try {
      const { id } = req.params;
      const ipAddress = (req as any).clientIp;

      const vote = await storage.getUserVote(id, ipAddress);
      res.json({ vote: vote?.voteType || null });
    } catch (error) {
      console.error("Error getting user vote:", error);
      res.status(500).json({ error: "Failed to get user vote" });
    }
  });

  // Increment view count
  app.post("/api/posts/:id/view", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.incrementViewCount(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error incrementing view count:", error);
      res.status(500).json({ error: "Failed to increment view count" });
    }
  });

  // Get comments for a post
  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const { id } = req.params;
      const comments = await storage.getCommentsForPost(id);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  // Create comment
  app.post("/api/posts/:id/comments", async (req, res) => {
    try {
      const { id } = req.params;
      const { name, content } = req.body;
      const ipAddress = (req as any).clientIp;

      if (!content || content.trim().length === 0) {
        return res.status(400).json({ error: "Comment content is required" });
      }

      const commentData = {
        postId: id,
        name: name || null,
        content: content.trim(),
      };

      const comment = await storage.createComment(commentData, ipAddress);
      res.status(201).json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  // Get active sessions count
  app.get("/api/sessions/active", async (req, res) => {
    try {
      const count = await storage.getActiveSessions();
      res.json({ activeUsers: count });
    } catch (error) {
      console.error("Error getting active sessions:", error);
      res.status(500).json({ error: "Failed to get active sessions" });
    }
  });

  // Get images only (for gallery)
  app.get("/api/images", async (req, res) => {
    try {
      const images = await storage.getImagesOnly();
      res.json(images);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
