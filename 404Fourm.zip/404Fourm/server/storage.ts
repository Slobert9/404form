import { type Post, type InsertPost, type Comment, type InsertComment, type Vote, type InsertVote, type Session } from "@shared/schema";
import { posts, comments, votes, sessions } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import { createHash } from "crypto";

export interface IStorage {
  // User methods (keeping existing)
  getUser(id: string): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  
  // Post methods
  getAllPosts(): Promise<Post[]>;
  createPost(post: InsertPost, ipAddress?: string, userAgent?: string): Promise<Post>;
  getImagesOnly(): Promise<Post[]>;
  incrementViewCount(postId: string): Promise<void>;
  
  // Voting methods
  voteOnPost(postId: string, voteType: 'up' | 'down', ipAddress: string): Promise<{ success: boolean; message: string }>;
  getUserVote(postId: string, ipAddress: string): Promise<Vote | null>;
  
  // Comment methods
  getCommentsForPost(postId: string): Promise<Comment[]>;
  createComment(comment: InsertComment, ipAddress?: string): Promise<Comment>;
  
  // Session methods
  trackSession(ipAddress: string, userAgent?: string): Promise<Session>;
  getActiveSessions(): Promise<number>;
}

const hashIpAddress = (ipAddress: string): string => {
  return createHash('sha256').update(ipAddress + 'salt_404_forum').digest('hex');
};

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<any | undefined> {
    // Legacy method - not used in current implementation
    return undefined;
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    // Legacy method - not used in current implementation
    return undefined;
  }

  async createUser(insertUser: any): Promise<any> {
    // Legacy method - not used in current implementation
    return insertUser;
  }

  async getAllPosts(): Promise<Post[]> {
    const allPosts = await db.select().from(posts).orderBy(desc(posts.createdAt));
    return allPosts;
  }

  async createPost(insertPost: InsertPost, ipAddress?: string, userAgent?: string): Promise<Post> {
    const postData: any = {
      ...insertPost,
      ipHash: ipAddress ? hashIpAddress(ipAddress) : null,
      userAgent: userAgent || null,
    };

    const [post] = await db.insert(posts).values(postData).returning();
    return post;
  }

  async getImagesOnly(): Promise<Post[]> {
    const imagePosts = await db
      .select()
      .from(posts)
      .where(sql`image_url IS NOT NULL`)
      .orderBy(desc(posts.createdAt));
    return imagePosts;
  }

  async incrementViewCount(postId: string): Promise<void> {
    await db
      .update(posts)
      .set({ viewCount: sql`view_count + 1` })
      .where(eq(posts.id, postId));
  }

  async voteOnPost(postId: string, voteType: 'up' | 'down', ipAddress: string): Promise<{ success: boolean; message: string }> {
    const ipHash = hashIpAddress(ipAddress);
    
    // Check if user already voted on this post
    const existingVote = await db
      .select()
      .from(votes)
      .where(and(eq(votes.postId, postId), eq(votes.ipHash, ipHash)))
      .limit(1);

    if (existingVote.length > 0) {
      const currentVote = existingVote[0];
      
      if (currentVote.voteType === voteType) {
        // Remove the vote (toggle off)
        await db.delete(votes).where(eq(votes.id, currentVote.id));
        
        // Update post vote count
        if (voteType === 'up') {
          await db.update(posts).set({ upvotes: sql`upvotes - 1` }).where(eq(posts.id, postId));
        } else {
          await db.update(posts).set({ downvotes: sql`downvotes - 1` }).where(eq(posts.id, postId));
        }
        
        return { success: true, message: 'Vote removed' };
      } else {
        // Change vote type
        await db.update(votes).set({ voteType }).where(eq(votes.id, currentVote.id));
        
        // Update post vote counts
        if (voteType === 'up') {
          await db.update(posts).set({ 
            upvotes: sql`upvotes + 1`,
            downvotes: sql`downvotes - 1`
          }).where(eq(posts.id, postId));
        } else {
          await db.update(posts).set({ 
            upvotes: sql`upvotes - 1`,
            downvotes: sql`downvotes + 1`
          }).where(eq(posts.id, postId));
        }
        
        return { success: true, message: 'Vote changed' };
      }
    } else {
      // Create new vote
      await db.insert(votes).values({
        postId,
        ipHash,
        voteType,
      });
      
      // Update post vote count
      if (voteType === 'up') {
        await db.update(posts).set({ upvotes: sql`upvotes + 1` }).where(eq(posts.id, postId));
      } else {
        await db.update(posts).set({ downvotes: sql`downvotes + 1` }).where(eq(posts.id, postId));
      }
      
      return { success: true, message: 'Vote added' };
    }
  }

  async getUserVote(postId: string, ipAddress: string): Promise<Vote | null> {
    const ipHash = hashIpAddress(ipAddress);
    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.postId, postId), eq(votes.ipHash, ipHash)))
      .limit(1);
    
    return vote || null;
  }

  async getCommentsForPost(postId: string): Promise<Comment[]> {
    const postComments = await db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(desc(comments.createdAt));
    return postComments;
  }

  async createComment(insertComment: InsertComment, ipAddress?: string): Promise<Comment> {
    const commentData = {
      ...insertComment,
      ipHash: ipAddress ? hashIpAddress(ipAddress) : undefined,
    };

    const [comment] = await db.insert(comments).values(commentData).returning();
    return comment;
  }

  async trackSession(ipAddress: string, userAgent?: string): Promise<Session> {
    const ipHash = hashIpAddress(ipAddress);
    
    // Check if session already exists
    const [existingSession] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.ipHash, ipHash))
      .limit(1);

    if (existingSession) {
      // Update last seen
      const [updatedSession] = await db
        .update(sessions)
        .set({ lastSeen: new Date(), isActive: true })
        .where(eq(sessions.id, existingSession.id))
        .returning();
      return updatedSession;
    } else {
      // Create new session
      const [newSession] = await db
        .insert(sessions)
        .values({ ipHash, userAgent })
        .returning();
      return newSession;
    }
  }

  async getActiveSessions(): Promise<number> {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    const activeSessions = await db
      .select()
      .from(sessions)
      .where(sql`last_seen > ${fiveMinutesAgo} AND is_active = true`);
    return activeSessions.length;
  }
}

export const storage = new DatabaseStorage();
