# replit.md

## Overview
A full-stack "404 Forum" hacker-themed family website with anonymous posting capabilities. Features a covert digital meeting spot aesthetic with terminal-style design, allowing family members to post thoughts, images, and messages without registration. Includes a functional forum page and dedicated image gallery with search functionality and real-time statistics.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Design System**: Dark theme with terminal/hacker aesthetic using green, blue, and amber accent colors

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with dedicated routes for posts and file uploads
- **File Handling**: Multer middleware for image upload processing with 10MB size limit
- **Development**: Hot reloading with Vite integration for development mode

### Data Storage Solutions
- **Database**: PostgreSQL configured through Drizzle ORM
- **Schema**: Single posts table with fields for id, name, content, image metadata, and timestamps
- **Development Storage**: In-memory storage implementation for development/testing
- **File Storage**: Local file system storage for uploaded images in uploads directory
- **Migrations**: Drizzle Kit for database schema management

### Authentication and Authorization
- **Authentication**: No authentication system implemented - anonymous posting allowed
- **Authorization**: Open access model with no user restrictions
- **Session Management**: Basic Express session handling prepared but not actively used

### External Dependencies
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **UI Components**: Radix UI primitives for accessible component foundation
- **Form Handling**: React Hook Form with Zod validation schemas
- **File Upload**: Native HTML file input with Multer backend processing
- **Icons**: Font Awesome and Lucide React icon libraries
- **Development Tools**: Replit-specific plugins for enhanced development experience
- **Deployment**: Configured for Replit hosting with environment variable support